# TODO List

- [x] Frontend integration of chatbot completed
- [ ] Final testing of the complete chatbot integration
