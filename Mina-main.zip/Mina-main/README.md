# MINA - Comprehensive Mental Health Platform

A fully integrated mental health application that combines AI-powered assessments, personalized chatbot support, and comprehensive user data tracking.

## 🚀 Features

### Core Functionality
- **AI-Powered Mental Health Assessments**: ML models predict depression, anxiety, and stress levels
- **Intelligent Chatbot**: Context-aware conversations using mental health dataset + user data
- **Progress Tracking**: Daily check-ins, streaks, and comprehensive statistics
- **Firebase Integration**: Real-time data sync and user authentication
- **Personalized Insights**: Tailored recommendations based on user patterns

### Technical Integration
- **Backend API**: Flask server with ML model integration
- **Frontend**: React TypeScript with modern UI
- **Data Services**: Unified data management across Firebase and local storage
- **Real-time Sync**: Automatic synchronization between frontend and backend
- **Comprehensive Logging**: Full user journey tracking

## 🏗️ Architecture

```
DEPRIS/
├── backend/                 # Flask API server
│   ├── app.py              # Main API with ML integration
│   └── requirements.txt    # Python dependencies
├── mental_health_model/    # AI/ML components
│   ├── chatbot.py         # Mental health chatbot
│   ├── predict.py         # ML prediction logic
│   ├── model_total/       # Trained ML models
│   └── MentalHealthChatbotDataset.json
├── project/               # React frontend
│   ├── src/
│   │   ├── components/    # UI components
│   │   ├── services/      # API and data services
│   │   │   ├── integrationService.ts  # Unified integration
│   │   │   ├── chatbotService.ts     # Enhanced chatbot
│   │   │   ├── mlService.ts          # ML API client
│   │   │   └── dataService.ts        # Data management
│   │   └── config/        # Firebase configuration
│   └── package.json
└── start.bat             # Quick startup script
```

## 🔧 Setup & Installation

### Prerequisites
- Python 3.8+
- Node.js 16+
- Firebase account (optional for full features)

### Quick Start
1. **Clone and navigate to project**:
   ```bash
   cd DEPRIS
   ```

2. **Install backend dependencies**:
   ```bash
   cd backend
   pip install -r requirements.txt
   ```

3. **Install frontend dependencies**:
   ```bash
   cd ../project
   npm install
   ```

4. **Start both servers**:
   ```bash
   # From DEPRIS root directory
   start.bat
   ```
   Or manually:
   ```bash
   # Terminal 1 - Backend
   cd backend && python app.py
   
   # Terminal 2 - Frontend  
   cd project && npm run dev
   ```

5. **Access the application**:
   - Frontend: http://localhost:5173
   - Backend API: http://localhost:5000

## 🤖 Chatbot Integration

The chatbot now provides comprehensive support by integrating:

### User Data Access
- **Assessment History**: "Show me my latest test results"
- **Progress Tracking**: "What's my check-in streak?"
- **Task Management**: "What tasks have I completed?"
- **Personalized Insights**: Context-aware responses based on user data

### Mental Health Support
- **Emotional Support**: Trained on comprehensive mental health dataset
- **Crisis Detection**: Identifies concerning language patterns
- **Coping Strategies**: Provides evidence-based techniques
- **Resource Guidance**: Connects users with appropriate help

### Example Interactions
```
User: "How am I doing with my mental health?"
Bot: "Based on your data: You have a 7-day check-in streak and have completed 3 assessments. Your latest assessment shows you're making progress. Keep up the excellent work with your mental health journey!"

User: "I'm feeling anxious today"
Bot: "I understand you're feeling anxious. Remember, anxiety is a normal human emotion. Have you tried any breathing exercises? Also, I see you've been consistent with your check-ins for 7 days - that shows real strength and commitment to your wellbeing."
```

## 📊 ML Model Integration

### Supported Predictions
- **Depression**: None, Mild, Moderate, Severe
- **Anxiety**: None, Mild, Moderate, Severe  
- **Stress**: Low, Moderate, High

### Assessment Mapping
9-question assessment mapped to 8 ML model features:
- PHQ-9 items (depression indicators)
- GAD-7 items (anxiety indicators)
- PSS items (stress indicators)
- Sleep quality metrics

## 🔐 Firebase Integration

### Authentication
- Email/password authentication
- User profile management
- Session persistence

### Data Storage
- Real-time assessment sync
- Check-in history
- User statistics
- Cross-device synchronization

## 🎯 Key Integrations

### 1. Unified Data Flow
```typescript
User Action → Integration Service → Backend API → ML Models
     ↓              ↓                    ↓           ↓
Firebase ← Data Service ← Response ← Predictions
```

### 2. Personalized Chatbot
- Accesses user's assessment history
- Incorporates progress data into responses
- Provides contextual mental health support
- Tracks conversation patterns

### 3. Comprehensive Analytics
- User journey tracking
- Progress trend analysis
- Personalized recommendations
- Intervention suggestions

## 🚀 Advanced Features

### Real-time Synchronization
- Automatic backend sync every 5 minutes
- Offline capability with local storage fallback
- Conflict resolution for concurrent updates

### Intelligent Insights
- Progress trend analysis
- Personalized recommendations
- Risk pattern detection
- Intervention timing optimization

### Scalable Architecture
- Microservices-ready design
- Database-agnostic data layer
- API-first approach
- Component-based frontend

## 🔧 Configuration

### Environment Variables
```bash
# Backend
VERIFY_FIREBASE=false
FIREBASE_PROJECT_ID=your-project-id
MODEL_DIR=../mental_health_model/model_total

# Frontend
VITE_API_URL=http://localhost:5000/api
```

### Firebase Setup
1. Create Firebase project
2. Enable Authentication and Firestore
3. Update `src/config/firebase.ts` with your config
4. Set environment variables for backend verification

## 📈 Usage Examples

### Taking an Assessment
```typescript
const responses = [2, 1, 3, 2, 1, 0, 2, 1, 2]; // 9 responses
const result = await integrationService.processAssessment(responses);
// Returns: predictions, report, user insights
```

### Chatbot Interaction
```typescript
const response = await integrationService.getPersonalizedChatResponse("How am I doing?");
// Returns: AI response + personalized user data context
```

### Getting User Insights
```typescript
const dashboard = await integrationService.getDashboardData();
// Returns: comprehensive user data, trends, recommendations
```

## 🤝 Contributing

This is a comprehensive mental health platform integrating:
- Machine Learning models for assessment
- AI chatbot with mental health training
- Real-time user data synchronization
- Firebase authentication and storage
- Personalized user experience

The system is designed to provide holistic mental health support through data-driven insights and compassionate AI interaction.

## 📄 License

This project is for educational and research purposes. Please ensure compliance with healthcare data regulations in production use.

---

**Note**: This integration provides a complete mental health platform where every component works together to deliver personalized, data-driven mental health support. The chatbot can access user progress, the ML models provide clinical insights, and the entire system maintains user context across all interactions.
