from flask import Flask, request, jsonify
from flask_cors import CORS
import joblib
import numpy as np
import os
import sys
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

# Add mental_health_model directory to path for imports
sys.path.append(os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')))
from mental_health_model.chatbot import MentalHealthChatbot

app = Flask(__name__)
CORS(app)  # Enable CORS for React frontend

# Initialize the chatbot
chatbot = MentalHealthChatbot()

# Firebase integration
try:
    import firebase_admin
    from firebase_admin import credentials, firestore
except ImportError:
    firebase_admin = None
    credentials = None
    firestore = None

from datetime import datetime, timedelta
import json

# Initialize Firebase (if credentials available)
db = None
try:
    if firebase_admin and not firebase_admin._apps:
        # Try to initialize with service account key file
        try:
            # Look for service account key in backend directory
            import os
            backend_dir = os.path.dirname(os.path.abspath(__file__))
            key_path = os.path.join(backend_dir, 'firebase-service-account.json')

            if os.path.exists(key_path):
                cred = credentials.Certificate(key_path)
                firebase_admin.initialize_app(cred)
                db = firestore.client() if firestore else None
                print("Firebase initialized successfully with service account key")
            else:
                # Fallback: try environment variables
                import os
                project_id = os.environ.get('FIREBASE_PROJECT_ID')
                private_key = os.environ.get('FIREBASE_PRIVATE_KEY')
                client_email = os.environ.get('FIREBASE_CLIENT_EMAIL')

                if project_id and private_key and client_email:
                    cred = credentials.Certificate({
                        "type": "service_account",
                        "project_id": project_id,
                        "private_key": private_key.replace('\\n', '\n'),
                        "client_email": client_email,
                        "token_uri": "https://oauth2.googleapis.com/token",
                    })
                    firebase_admin.initialize_app(cred)
                    db = firestore.client() if firestore else None
                    print("Firebase initialized successfully with environment variables")
                else:
                    raise FileNotFoundError("No Firebase credentials found")

        except Exception as cred_error:
            print(f"Credential initialization failed: {cred_error}")
            # Final fallback: try default credentials
            try:
                cred = credentials.ApplicationDefault()
                firebase_admin.initialize_app(cred)
                db = firestore.client() if firestore else None
                print("Firebase initialized successfully with default credentials")
            except Exception as default_error:
                print(f"All Firebase initialization methods failed: {default_error}")
                print("Running in offline mode - data will be stored locally")
                db = None

except Exception as e:
    print(f"Firebase initialization failed: {e}")
    print("Running in offline mode - data will be stored locally")
    db = None

def get_user_id():
    """Extract user ID from request headers"""
    auth_header = request.headers.get('Authorization', '')
    if auth_header.startswith('Bearer '):
        return auth_header.split('Bearer ')[1]
    return None

def calculate_checkin_streak(user_id, checkin_ids):
    """Calculate the current check-in streak for a user"""
    try:
        if not db or not checkin_ids:
            return 0

        # Get check-in dates from Firebase
        streak = 0
        today = datetime.now().date()

        for i in range(30):  # Check last 30 days
            check_date = today - timedelta(days=i)
            date_str = check_date.strftime('%Y-%m-%d')
            checkin_id = f"{user_id}-{date_str}"

            if checkin_id in checkin_ids:
                try:
                    checkin_doc = db.collection('checkIns').document(checkin_id).get()
                    if checkin_doc.exists and checkin_doc.to_dict().get('completed', False):
                        streak += 1
                    else:
                        break
                except:
                    # If we can't fetch the document, assume it's completed if in the list
                    streak += 1
            else:
                break

        return streak
    except Exception as e:
        print(f"Error calculating streak: {e}")
        return 0

def get_user_data(user_id):
    """Fetch user data from Firebase or return default structure"""
    if not user_id:
        return None

    try:
        if db:
            # Try to get user data from Firebase
            user_doc = db.collection('users').document(user_id).get()
            if user_doc.exists:
                user_data = user_doc.to_dict()
                # Ensure all required fields exist
                if 'stats' not in user_data:
                    user_data['stats'] = {
                        'checkInStreak': 0,
                        'totalAssessments': 0,
                        'lastAssessmentDate': None
                    }
                if 'assessments' not in user_data:
                    user_data['assessments'] = []
                if 'checkIns' not in user_data:
                    user_data['checkIns'] = []
                return user_data

        # Return default structure if no Firebase data or Firebase unavailable
        return {
            'id': user_id,
            'assessments': [],
            'checkIns': [],
            'stats': {
                'checkInStreak': 0,
                'totalAssessments': 0,
                'lastAssessmentDate': None
            }
        }
    except Exception as e:
        print(f"Error fetching user data: {e}")
        return {
            'id': user_id,
            'assessments': [],
            'checkIns': [],
            'stats': {
                'checkInStreak': 0,
                'totalAssessments': 0,
                'lastAssessmentDate': None
            }
        }

# Reverse-score mapping
REVERSE_SCORE = {
    'PSS4': 3  # scale 0-3
}

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MODEL_DIR = os.environ.get('MODEL_DIR') or os.path.normpath(os.path.join(BASE_DIR, '..', 'mental_health_model', 'model_total'))

def predict_all_labels(user_inputs):
    """Predict depression, anxiety, and stress levels using the ML models"""
    results = {}
    model_dir = MODEL_DIR
    if not os.path.isdir(model_dir):
        return {
            'Depression': {'label': 'Unknown', 'confidence': 0.0, 'error': f'Model directory not found: {model_dir}'},
            'Anxiety': {'label': 'Unknown', 'confidence': 0.0, 'error': f'Model directory not found: {model_dir}'},
            'Stress': {'label': 'Unknown', 'confidence': 0.0, 'error': f'Model directory not found: {model_dir}'}
        }

    # Helper to auto-detect artifacts with flexible filenames
    try:
        available = {f.lower(): os.path.join(model_dir, f) for f in os.listdir(model_dir)}
    except Exception as e:
        return {
            'Depression': {'label': 'Unknown', 'confidence': 0.0, 'error': f'Unable to list model_dir: {e}'},
            'Anxiety': {'label': 'Unknown', 'confidence': 0.0, 'error': f'Unable to list model_dir: {e}'},
            'Stress': {'label': 'Unknown', 'confidence': 0.0, 'error': f'Unable to list model_dir: {e}'}
        }

    def pick_file(preferred: str, fallbacks_contains: list[str]):
        key = preferred.lower()
        if key in available:
            return available[key]
        for needle in fallbacks_contains:
            for fname, fpath in available.items():
                if needle in fname:
                    return fpath
        return None

    for name in ['Depression', 'Anxiety', 'Stress']:
        try:
            # Resolve filenames flexibly
            lower = name.lower()
            model_path = pick_file(f"{lower}_model.pkl", [f"{lower}_model", lower, "model"]) 
            scaler_path = pick_file("combined_scaler.pkl", ["scaler"])
            features_path = pick_file(f"{lower}_features.pkl", [f"{lower}_features", "features"])
            le_path = pick_file(f"{lower}_label_encoder.pkl", [f"{lower}_label", "label_encoder", "encoder"])

            missing = [
                part for part, path in [
                    (f"{name} model", model_path),
                    ("scaler", scaler_path),
                    (f"{name} features", features_path),
                    (f"{name} label encoder", le_path)
                ] if path is None
            ]
            if missing:
                raise FileNotFoundError(f"Missing artifacts: {', '.join(missing)} in {model_dir}")

            # Load model, scaler, features, label encoder
            model = joblib.load(model_path)
            scaler = joblib.load(scaler_path)
            features = joblib.load(features_path)
            le = joblib.load(le_path)

            # Prepare input
            inputs = user_inputs.copy()
            for feat, max_val in REVERSE_SCORE.items():
                if feat in inputs:
                    inputs[feat] = max_val - inputs[feat]

            X = np.array([inputs[f] for f in features]).reshape(1, -1)
            X_scaled = scaler.transform(X)

            # Predict
            y_pred_enc = model.predict(X_scaled)[0]
            y_prob_enc = model.predict_proba(X_scaled)[0]

            # Decode label
            label = le.inverse_transform([y_pred_enc])[0]
            probs = {le.inverse_transform([i])[0]: float(y_prob_enc[i]) for i in range(len(y_prob_enc))}

            results[name] = {
                'label': label,
                'probabilities': probs,
                'confidence': float(y_prob_enc[y_pred_enc])  # Highest probability
            }
        except Exception as e:
            results[name] = {
                'error': f"Failed to load {name} model: {str(e)}",
                'label': 'Unknown',
                'confidence': 0.0
            }

    return results

def map_assessment_to_model_input(responses):
    """Map the 9-question assessment to the 8-feature model input format"""
    # Map assessment responses to model features
    # Assessment questions 0-7: 0-3 scale (Not at all -> Nearly every day)
    # Question 8: Sleep hours (0: <4h, 1: 4-6h, 2: 7-8h, 3: >8h)
    
    return {
        "PHQ1": responses[0],  # Little interest
        "PHQ2": responses[1],  # Feeling down
        "GAD1": responses[7],  # Nervous/anxious (question 8 in original order)
        "GAD2": 2,             # Default value - this might need adjustment
        "PSS10": 2,            # Default value - consider adding more questions
        "PSS4": responses[2],  # Sleep trouble (question 3)
        "PHQ7": responses[3],  # Feeling tired (question 4)
        "Sleep_Hours": responses[8]  # Sleep hours (question 9)
    }

@app.route('/api/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({
        "status": "healthy",
        "message": "ML API is running",
        "model_dir": MODEL_DIR,
    })

@app.route('/', methods=['GET'])
def root():
    return jsonify({
        "message": "MindWell ML API",
        "endpoints": ["/api/health", "/api/predict", "/api/test"]
    })

@app.route('/api/predict', methods=['POST'])
def predict():
    """Predict mental health scores from assessment responses"""
    try:
        data = request.get_json()
        user_id = get_user_id()
        
        if not data or 'responses' not in data:
            return jsonify({"error": "No responses provided"}), 400
        
        responses = data['responses']
        
        if len(responses) != 9:
            return jsonify({"error": "Expected 9 responses"}), 400
        
        # Map assessment responses to model input format
        model_inputs = map_assessment_to_model_input(responses)
        
        # Get predictions
        predictions = predict_all_labels(model_inputs)
        
        # Generate summary report
        report = generate_report(predictions)
        
        return jsonify({
            "predictions": predictions,
            "report": report,
            "success": True
        })
        
    except Exception as e:
        return jsonify({"error": str(e), "success": False}), 500

def generate_report(predictions):
    """Generate a comprehensive mental health report based on predictions"""
    report_lines = []
    
    for condition, result in predictions.items():
        if 'error' in result:
            report_lines.append(f"{condition}: Unable to assess due to technical issue.")
            continue
            
        level = result['label']
        confidence = result['confidence'] * 100
        
        if condition == 'Depression':
            if level == 'None':
                report_lines.append(f"Depression: Your responses suggest minimal depressive symptoms. Confidence: {confidence:.1f}%")
            elif level == 'Mild':
                report_lines.append(f"Depression: You're experiencing mild symptoms that may benefit from attention. Confidence: {confidence:.1f}%")
            elif level == 'Moderate':
                report_lines.append(f"Depression: Moderate symptoms detected. Consider speaking with a professional. Confidence: {confidence:.1f}%")
            elif level == 'Severe':
                report_lines.append(f"Depression: Significant symptoms detected. We recommend professional evaluation. Confidence: {confidence:.1f}%")
                
        elif condition == 'Anxiety':
            if level == 'None':
                report_lines.append(f"Anxiety: Minimal anxiety symptoms detected. Confidence: {confidence:.1f}%")
            elif level == 'Mild':
                report_lines.append(f"Anxiety: Mild anxiety present. Relaxation techniques may help. Confidence: {confidence:.1f}%")
            elif level == 'Moderate':
                report_lines.append(f"Anxiety: Moderate anxiety levels. Professional guidance recommended. Confidence: {confidence:.1f}%")
            elif level == 'Severe':
                report_lines.append(f"Anxiety: Severe anxiety detected. Please seek professional support. Confidence: {confidence:.1f}%")
                
        elif condition == 'Stress':
            if level == 'Low':
                report_lines.append(f"Stress: You're managing stress well. Confidence: {confidence:.1f}%")
            elif level == 'Moderate':
                report_lines.append(f"Stress: Moderate stress levels. Consider stress management techniques. Confidence: {confidence:.1f}%")
            elif level == 'High':
                report_lines.append(f"Stress: High stress detected. Professional support may be beneficial. Confidence: {confidence:.1f}%")
    
    # Add disclaimer
    report_lines.append("\nNote: This assessment is for informational purposes only and should not replace professional medical advice.")
    
    return "\n".join(report_lines)

@app.route('/api/test', methods=['GET'])
def test_prediction():
    """Test endpoint with sample data"""
    sample_inputs = {
        "PHQ1": 2,
        "PHQ2": 1,
        "GAD1": 3,
        "GAD2": 2,
        "PSS10": 2,
        "PSS4": 1,
        "PHQ7": 2,
        "Sleep_Hours": 6
    }
    
    predictions = predict_all_labels(sample_inputs)
    report = generate_report(predictions)
    
    return jsonify({
        "sample_input": sample_inputs,
        "predictions": predictions,
        "report": report
    })

@app.route('/api/user/latest-assessment', methods=['GET'])
def get_latest_assessment():
    """Get latest assessment report for authenticated user"""
    user_id = get_user_id()
    if not user_id:
        return jsonify({"error": "User not authenticated"}), 401
    
    user_data = get_user_data(user_id)
    if not user_data:
        return jsonify({"error": "User data not found"}), 404
    
    # Get latest assessment
    latest_assessment = {
        "date": user_data['stats']['lastAssessmentDate'].isoformat() if user_data['stats']['lastAssessmentDate'] else None,
        "report": "Your latest assessment shows you're making progress. Keep up the good work with your mental health journey!",
        "totalAssessments": user_data['stats']['totalAssessments']
    }
    
    return jsonify({"latest_assessment": latest_assessment, "success": True})

@app.route('/api/user/todays-tasks', methods=['GET'])
def get_todays_tasks():
    """Get today's tasks and completion status for authenticated user"""
    user_id = get_user_id()
    if not user_id:
        return jsonify({"error": "User not authenticated"}), 401
    
    user_data = get_user_data(user_id)
    if not user_data:
        return jsonify({"error": "User data not found"}), 404
    
    # Generate today's tasks based on user progress
    streak = user_data['stats']['checkInStreak']
    todays_tasks = [
        {"task": "Complete daily check-in", "completed": streak > 0},
        {"task": "Practice mindfulness (5 min)", "completed": False},
        {"task": "Review mental health resources", "completed": True if streak > 3 else False}
    ]
    
    return jsonify({"todays_tasks": todays_tasks, "success": True})

@app.route('/api/user/sync-assessment', methods=['POST'])
def sync_assessment():
    """Sync assessment data from frontend"""
    user_id = get_user_id()
    if not user_id:
        return jsonify({"error": "User not authenticated"}), 401

    data = request.get_json()
    if not data:
        return jsonify({"error": "No data provided"}), 400

    try:
        if db:
            # Save assessment to Firebase
            assessment_ref = db.collection('assessments').document(data.get('id', f"{user_id}-{datetime.now().isoformat()}"))
            assessment_ref.set({
                'userId': user_id,
                'responses': data.get('responses', []),
                'predictions': data.get('predictions', {}),
                'report': data.get('report', ''),
                'date': data.get('date', datetime.now().isoformat()),
                'timestamp': datetime.now()
            })

            # Update user stats
            user_ref = db.collection('users').document(user_id)
            user_doc = user_ref.get()
            user_data = user_doc.to_dict() if user_doc.exists else {}

            assessments = user_data.get('assessments', [])
            assessments.append(data.get('id', f"{user_id}-{datetime.now().isoformat()}"))

            user_ref.set({
                'id': user_id,
                'assessments': assessments,
                'stats': {
                    'totalAssessments': len(assessments),
                    'lastAssessmentDate': datetime.now().isoformat(),
                    'checkInStreak': user_data.get('stats', {}).get('checkInStreak', 0)
                },
                'lastUpdated': datetime.now()
            }, merge=True)

        return jsonify({"success": True, "message": "Assessment synced"})
    except Exception as e:
        print(f"Error syncing assessment: {e}")
        return jsonify({"error": f"Failed to sync assessment: {str(e)}"}), 500

@app.route('/api/user/sync-checkin', methods=['POST'])
def sync_checkin():
    """Sync check-in data from frontend"""
    user_id = get_user_id()
    if not user_id:
        return jsonify({"error": "User not authenticated"}), 401

    data = request.get_json()
    if not data:
        return jsonify({"error": "No data provided"}), 400

    try:
        if db:
            # Save check-in to Firebase
            checkin_ref = db.collection('checkIns').document(f"{user_id}-{data.get('date', datetime.now().strftime('%Y-%m-%d'))}")
            checkin_ref.set({
                'userId': user_id,
                'date': data.get('date', datetime.now().strftime('%Y-%m-%d')),
                'completed': data.get('completed', False),
                'mood': data.get('mood', ''),
                'notes': data.get('notes', ''),
                'timestamp': datetime.now()
            })

            # Update user stats
            user_ref = db.collection('users').document(user_id)
            user_doc = user_ref.get()
            user_data = user_doc.to_dict() if user_doc.exists else {}

            checkIns = user_data.get('checkIns', [])
            checkin_id = f"{user_id}-{data.get('date', datetime.now().strftime('%Y-%m-%d'))}"
            if checkin_id not in checkIns:
                checkIns.append(checkin_id)

            # Calculate check-in streak
            checkin_streak = calculate_checkin_streak(user_id, checkIns)

            user_ref.set({
                'id': user_id,
                'checkIns': checkIns,
                'stats': {
                    'checkInStreak': checkin_streak,
                    'totalAssessments': user_data.get('stats', {}).get('totalAssessments', 0),
                    'lastAssessmentDate': user_data.get('stats', {}).get('lastAssessmentDate')
                },
                'lastUpdated': datetime.now()
            }, merge=True)

        return jsonify({"success": True, "message": "Check-in synced"})
    except Exception as e:
        print(f"Error syncing check-in: {e}")
        return jsonify({"error": f"Failed to sync check-in: {str(e)}"}), 500

@app.route('/api/user/stats', methods=['GET'])
def get_user_stats():
    """Get comprehensive user statistics"""
    user_id = get_user_id()
    if not user_id:
        return jsonify({"error": "User not authenticated"}), 401
    
    user_data = get_user_data(user_id)
    if not user_data:
        return jsonify({"error": "User data not found"}), 404
    
    stats = user_data['stats']
    return jsonify({
        "stats": {
            "checkInStreak": stats['checkInStreak'],
            "totalAssessments": stats['totalAssessments'],
            "lastAssessmentDate": stats['lastAssessmentDate'].isoformat() if stats['lastAssessmentDate'] else None,
            "weeklyProgress": min(stats['checkInStreak'], 7),
            "monthlyGoal": 30,
            "currentMonth": stats['checkInStreak']
        },
        "success": True
    })

@app.route('/api/chat', methods=['POST'])
def chat():
    """Enhanced chatbot endpoint with user data integration"""
    try:
        data = request.get_json()
        if not data or 'message' not in data:
            return jsonify({"error": "No message provided", "success": False}), 400
        
        user_message = data['message']
        user_id = get_user_id()
        
        # Get user data for personalized responses
        user_data = get_user_data(user_id) if user_id else None
        
        lower_msg = user_message.lower()
        response_text = ""
        
        # Handle user-specific queries
        if user_data and any(keyword in lower_msg for keyword in ["assessment", "test report", "latest report"]):
            stats = user_data['stats']
            if stats['lastAssessmentDate']:
                date_str = stats['lastAssessmentDate'].strftime('%B %d, %Y')
                response_text = f"Your most recent assessment was on {date_str}. You've completed {stats['totalAssessments']} assessments total. Your progress shows you're actively working on your mental health journey!"
            else:
                response_text = "I don't see any recent assessments. Taking regular assessments helps track your mental health progress. Would you like to take one now?"
        
        elif user_data and any(keyword in lower_msg for keyword in ["tasks", "completed", "progress"]):
            streak = user_data['stats']['checkInStreak']
            response_text = f"You're doing great! Your current check-in streak is {streak} days. {'Keep up the excellent work!' if streak > 0 else 'Every journey starts with a single step - would you like to start your streak today?'}"
        
        elif user_data and any(keyword in lower_msg for keyword in ["streak", "check-in"]):
            streak = user_data['stats']['checkInStreak']
            if streak >= 7:
                response_text = f"Wow! You have a {streak}-day streak! That's fantastic consistency. You're building great mental health habits."
            elif streak > 0:
                response_text = f"You're on a {streak}-day streak! You're building momentum - keep it up!"
            else:
                response_text = "Ready to start your mental health journey? Every day you check in is a step toward better wellbeing."
        
        elif any(keyword in lower_msg for keyword in ["help", "how to use", "features"]):
            response_text = (
                "I'm your mental health companion! I can help you with:\n\n"
                "• Track your daily check-ins and build streaks\n"
                "• Review your assessment results and progress\n"
                "• Provide emotional support and coping strategies\n"
                "• Answer questions about mental health\n"
                "• Guide you through mindfulness exercises\n\n"
                "Just ask me about your progress, share how you're feeling, or ask for help with anything!"
            )
        
        else:
            # Use the mental health chatbot for general conversations
            response_text = chatbot.get_response(user_message)
            
            # Add personalized context if user is authenticated
            if user_data and any(keyword in lower_msg for keyword in ["sad", "depressed", "anxious", "stressed"]):
                streak = user_data['stats']['checkInStreak']
                if streak > 0:
                    response_text += f" Remember, you've been consistent with your check-ins for {streak} days - that shows real strength and commitment to your wellbeing."
        
        return jsonify({
            "response": response_text,
            "success": True
        })
        
    except Exception as e:
        return jsonify({"error": str(e), "success": False}), 500

if __name__ == '__main__':
    print("Starting MindWell Backend Server...")
    print(f"Model directory: {MODEL_DIR}")
    print("Available endpoints:")
    print("  GET  /api/health - Health check")
    print("  POST /api/predict - Mental health predictions")
    print("  GET  /api/test - Test prediction endpoint")
    print("  POST /api/chat - Chatbot interactions")
    print("  GET  /api/user/stats - User statistics")
    print("  GET  /api/user/latest-assessment - Latest assessment")
    print("  GET  /api/user/todays-tasks - Today's tasks")
    print("\nServer running on http://localhost:5000")
    app.run(debug=True, host='0.0.0.0', port=5000)