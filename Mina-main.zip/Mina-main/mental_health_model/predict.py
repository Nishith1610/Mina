# predict.py
import joblib
import numpy as np

# Reverse-score mapping
REVERSE_SCORE = {
    'PSS4': 3  # scale 0-3
}

def predict_all_labels(user_inputs):
    results = {}

    for name in ['Depression', 'Anxiety', 'Stress']:
        # Load model, scaler, features, label encoder
        model = joblib.load(f"ml-model/model_total/{name.lower()}_model.pkl")
        scaler = joblib.load("ml-model/model_total/combined_scaler.pkl")
        features = joblib.load(f"ml-model/model_total/{name.lower()}_features.pkl")
        le = joblib.load(f"ml-model/model_total/{name.lower()}_label_encoder.pkl")

        # Prepare input
        inputs = user_inputs.copy()
        for feat, max_val in REVERSE_SCORE.items():
            if feat in inputs:
                inputs[feat] = max_val - inputs[feat]

        X = np.array([inputs[f] for f in features]).reshape(1, -1)
        X_scaled = scaler.transform(X)

        # Predict
        y_pred_enc = model.predict(X_scaled)[0]
        y_prob_enc = model.predict_proba(X_scaled)[0]

        # Decode label
        label = le.inverse_transform([y_pred_enc])[0]
        probs = {le.inverse_transform([i])[0]: float(y_prob_enc[i]) for i in range(len(y_prob_enc))}

        results[name] = {
            'label': label,
            'probabilities': probs
        }

    return results


# ======================
# Example usage
# ======================
if __name__ == "__main__":
    user_inputs = {
        "PHQ1": 2,
        "PHQ2": 1,
        "GAD1": 3,
        "GAD2": 2,
        "PSS10": 2,
        "PSS4": 1,
        "PHQ7": 2,
        "Sleep_Hours": 6
    }

    prediction = predict_all_labels(user_inputs)

    print("\nPredicted Mental Health Levels:")
    for cond, info in prediction.items():
        print(f"\n{cond}:")
        print(f"  Label: {info['label']}")
       