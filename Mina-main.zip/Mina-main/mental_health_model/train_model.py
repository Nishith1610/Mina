# train_model.py
import pandas as pd
import joblib
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder
from xgboost import XGBClassifier
import os
import numpy as np
from sklearn.utils import class_weight

# Paths
DATA_PATH = "mental_health_model/data/processed_data1.csv"
SAVE_DIR = "mental_health_model/model_total"
os.makedirs(SAVE_DIR, exist_ok=True)

# Load dataset
df = pd.read_csv(DATA_PATH)

# -----------------------------
# Feature mapping (8 questions + sleep_hours)
# -----------------------------
df['PSS4'] = 3 - df['PSS4']  # Reverse-score PSS4

features = [
    'PHQ1',        # Little interest
    'PHQ2',        # Feeling down
    'GAD1',        # Feeling nervous
    'GAD2',        # Worrying too much
    'PSS10',       # Life out of control
    'PSS4',        # Overwhelmed (reverse scored)
    'PHQ7',        # Feeling tired
    'Sleep_Hours'  # Average sleep
]

targets = {
    'Depression': 'Depression Label',
    'Anxiety': 'Anxiety Label',
    'Stress': 'Stress Label'
}

# Scale features
scaler = StandardScaler()
X_scaled = scaler.fit_transform(df[features])
joblib.dump(scaler, f"{SAVE_DIR}/combined_scaler.pkl")  # Save scaler once

# Train each model separately
for name, target_col in targets.items():
    print(f"\n🔹 Training {name} model...")

    y = df[target_col]
    le = LabelEncoder()
    y_encoded = le.fit_transform(y)
    joblib.dump(le, f"{SAVE_DIR}/{name.lower()}_label_encoder.pkl")

    X_train, X_test, y_train, y_test = train_test_split(
        X_scaled, y_encoded, test_size=0.2, random_state=42, stratify=y_encoded
    )

    # Optional: handle class imbalance
    class_weights = class_weight.compute_class_weight(
        class_weight='balanced',
        classes=np.unique(y_train),
        y=y_train
    )
    weight_dict = dict(zip(np.unique(y_train), class_weights))

    model = XGBClassifier(
        eval_metric='mlogloss',
        random_state=42,
        n_estimators=300,
        max_depth=4,
        learning_rate=0.1,
        subsample=0.8,
        colsample_bytree=0.8,
        scale_pos_weight=1  # handled via sample_weight if needed
    )

    # Train model
    model.fit(X_train, y_train)

    acc = model.score(X_test, y_test)
    print(f"✅ {name} model accuracy: {acc:.2f}")

    # Save model and features
    joblib.dump(model, f"{SAVE_DIR}/{name.lower()}_model.pkl")
    joblib.dump(features, f"{SAVE_DIR}/{name.lower()}_features.pkl")

print("\n🎉 All three models trained and saved successfully!")
