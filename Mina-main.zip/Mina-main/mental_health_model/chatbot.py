# chatbot.py
import json
import random
import os
import re

class MentalHealthChatbot:
    def __init__(self, dataset_path=None):
        """
        Initialize the Mental Health Chatbot with the dataset
        """
        if dataset_path is None:
            # Default path relative to this file
            current_dir = os.path.dirname(os.path.abspath(__file__))
            dataset_path = os.path.join(current_dir, 'MentalHealthChatbotDataset.json')
        
        self.load_dataset(dataset_path)
    
    def load_dataset(self, dataset_path):
        """
        Load the dataset from the JSON file
        """
        try:
            with open(dataset_path, 'r', encoding='utf-8') as file:
                data = json.load(file)
                self.intents = data['intents']
                print(f"Loaded {len(self.intents)} intents from dataset")
        except Exception as e:
            print(f"Error loading dataset: {str(e)}")
            self.intents = []
    
    def preprocess_text(self, text):
        """
        Preprocess the input text: lowercase, remove punctuation
        """
        text = text.lower()
        text = re.sub(r'[^\w\s]', '', text)  # Remove punctuation
        return text
    
    def get_response(self, user_input):
        """
        Get a response based on the user input
        """
        if not user_input.strip():
            return "I didn't catch that. Could you please say something?"
        
        preprocessed_input = self.preprocess_text(user_input)
        
        # Find the best matching intent
        best_match = self._find_best_match(preprocessed_input)
        
        if best_match:
            # Return a random response from the matched intent
            return random.choice(best_match['responses'])
        else:
            # Default response if no match is found
            return "I'm not sure how to respond to that. Could you rephrase or ask me something about how you're feeling?"
    
    def _find_best_match(self, preprocessed_input):
        """
        Find the best matching intent for the preprocessed input
        """
        best_match = None
        highest_score = 0
        
        for intent in self.intents:
            score = self._calculate_match_score(preprocessed_input, intent['patterns'])
            if score > highest_score:
                highest_score = score
                best_match = intent
        
        # Only return a match if the score is above a threshold
        if highest_score > 0.3:  # Threshold can be adjusted
            return best_match
        return None
    
    def _calculate_match_score(self, preprocessed_input, patterns):
        """
        Calculate a match score between the input and patterns
        """
        # Simple word matching algorithm
        input_words = set(preprocessed_input.split())
        
        best_pattern_score = 0
        for pattern in patterns:
            preprocessed_pattern = self.preprocess_text(pattern)
            pattern_words = set(preprocessed_pattern.split())
            
            # Calculate Jaccard similarity
            if not input_words or not pattern_words:
                continue
                
            intersection = len(input_words.intersection(pattern_words))
            union = len(input_words.union(pattern_words))
            
            if union > 0:
                similarity = intersection / union
                best_pattern_score = max(best_pattern_score, similarity)
            
            # Exact match bonus
            if preprocessed_input == preprocessed_pattern:
                best_pattern_score = 1.0
                break
        
        return best_pattern_score

# Example usage
if __name__ == "__main__":
    chatbot = MentalHealthChatbot()
    
    print("Mental Health Chatbot initialized. Type 'quit' to exit.")
    
    while True:
        user_input = input("You: ")
        if user_input.lower() in ['quit', 'exit', 'bye']:
            print("Chatbot: Take care of yourself. Goodbye!")
            break
        
        response = chatbot.get_response(user_input)
        print(f"Chatbot: {response}")